﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


static class ASCIIVAL
{
    public const int A = 65;
    public const int B = 66;
    public const int C = 67;
    public const int D = 68;
    public const int E = 69;
    public const int F = 70;
    public const int ZERO   = 30;
    public const int ONE    = 31;
    public const int TWO    = 32;
    public const int THREE  = 33;
    public const int FOUR   = 34;
    public const int FIVE   = 35;
    public const int SIX    = 36;
    public const int SEVEN  = 37;
    public const int EIGHT  = 38;
    public const int NINE   = 39;
}


namespace ConvertNumber
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //lable에 text 입히기 - 방법1(string 사용)
            string[] strTmp = { "변경전(変更前)\nBefore", "변경후(変更後)\nAfter", "바꾸기(変化)\nConvert", "초기화(初基化)\nInitaillize", "닫기(終)\nClose" };
            lblBefore.Content = strTmp[0];
            lblAfter.Content = strTmp[1];
            btnConvert.Content = strTmp[2];
            btnInit.Content = strTmp[3];
            btnQuit.Content = strTmp[4];

            //label에 text 입히기 - 방법2(StringBuilder 사용) 
            //    StringBuilder temp = new StringBuilder("변경전(変更前)\nBefore",32);
            //    StringBuilder temp2 = new StringBuilder("변경후(変更後)\nAfter", 32);
            //    lblBefore.Content = temp;
            //    lblAfter.Content = temp2;
            //    lblBefore.UpdateLayout();
        }

        private void btnConvert_Click(object sender, RoutedEventArgs e) //변경하기
        {
            string getBefore = "";
            getBefore = tbBefore.Text;
            getBefore = getBefore.Trim();           //좌우공백제거 - get rid of blank left side and right side.
        //    getBefore = getBefore.Replace(" ",""); //문자열 중간에 있는 공백제거
            getBefore = getBefore.ToUpper();        //대문자전환 - lower letter -> upper letter

            int nRepeat = 0;
            int nNum = -1;
            // 16진수 값을 변경전에 입력한 문자가 변환이 가능한지 체크한다
            for (nRepeat = 0; nRepeat < getBefore.Length; nRepeat++)
            {
                nNum = getBefore[nRepeat]; //아스키 코드로 확인한다.

                //아스키코드값이 0~9 범위 밖인 경우 판단하기
                if( nNum < ASCIIVAL.ZERO && nNum > ASCIIVAL.NINE)
                {
                    // 입력값이 16진수인 경우 A,B,C,D,E,F를 확인한다
                    if (nNum != ASCIIVAL.A && nNum != ASCIIVAL.B && nNum != ASCIIVAL.C && nNum != ASCIIVAL.D && nNum != ASCIIVAL.E && nNum != ASCIIVAL.F)
                    {
                        MessageBox.Show("16진수 값을 벗어났습니다\n숫자와 문자(a~f)외에는 허용하지 않습니다", "에러", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }
            }            
            // 변환을 시작한다.
            nNum = Convert.ToInt32(getBefore, 16);  //16진수 -> 10진수
            tbAfter.Text = Convert.ToString(nNum, 2);   //10진수 -> 2진수 
        }

        private void btnInit_Click(object sender, RoutedEventArgs e) //초기화
        {
            if (tbBefore.Text.Length != 0)
                tbBefore.Clear();

            if (tbAfter.Text.Length != 0)
                tbAfter.Clear();
        }

        private void btnQuit_Click(object sender, RoutedEventArgs e) //종료
        {
            MessageBoxResult result = MessageBox.Show("종료하시겠습니까?", "종료", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                this.Close();
            }
            else if (result == MessageBoxResult.No)
                return;
        }
    }
}
